# Recommendation Experiments
import os
import time
import spotipy
from spotipy.oauth2 import SpotifyOAuth
import pandas as pd
import numpy as np
import joblib
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.callbacks import EarlyStopping
import random
import pickle
from tensorflow.keras.layers import TextVectorization
from spotipy.oauth2 import SpotifyClientCredentials

def run_ml_model(sp):

    #sp_oauth = spotipy.oauth2.SpotifyOAuth(
   #     client_id=client_id,
    #    client_secret=client_secret,
     #   redirect_uri=redirect_uri,
      #  scope=SCOPE,
       # cache_path=f"cache_{np.random.randint(1230414)}")
    saved_model = load_model("C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\best_model.keras")
    df = pd.read_csv('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\EMT_df_son.csv', index_col= [0])
    scaler = joblib.load('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\scaler.pkl')
    pca = joblib.load('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\pca.pkl')
    with open('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\text_vectorizer.pkl', 'rb') as f:
        text_vectorizer_data = pickle.load(f)
        text_vectorizer = TextVectorization.from_config(text_vectorizer_data['config'])
        text_vectorizer.set_weights(text_vectorizer_data['weights'])
    # Fetch user's profile information
    user_profile = sp.current_user()
    user_id = user_profile['id']
    user_name = user_profile['display_name']
    
    print(user_name)
    recently_played = sp.current_user_recently_played(limit=50)['items']

    # Fetch top listening tracks for different time ranges
    top_tracks_short_term = sp.current_user_top_tracks(limit=50, time_range='short_term')['items']
    top_tracks_medium_term = sp.current_user_top_tracks(limit=50, time_range='medium_term')['items']
    top_tracks_long_term = sp.current_user_top_tracks(limit=50, time_range='long_term')['items']

    # Get track IDs from the user's DataFrame
    user_track_ids = df[df['owner_id'] == user_id]['track_id'].tolist()

    # Initialize lists to store track details
    track_details = []


    # Function to get track features and artist genres
    def get_track_info(track):
        track_id = track['id']
        track_name = track['name']
        owner_id = user_id
        owner_name = user_name
        has_listened = 1
        duration_ms = track['duration_ms']

        # Get track features
        time.sleep(0.1)
        features = sp.audio_features(track_id)[0]
        danceability = features['danceability']
        energy = features['energy']
        key = features['key']
        loudness = features['loudness']
        mode = features['mode']
        speechiness = features['speechiness']
        acousticness = features['acousticness']
        instrumentalness = features['instrumentalness']
        liveness = features['liveness']
        valence = features['valence']
        tempo = features['tempo']
        time_signature = features['time_signature']

        # Get artist genres
        artist_id = track['artists'][0]['id']
        artist_info = sp.artist(artist_id)
        genres = artist_info['genres']

        return [owner_id, track_id, has_listened, owner_name, track_name, duration_ms, danceability, energy, key, loudness,
                mode, speechiness, acousticness, instrumentalness, liveness, valence, tempo, time_signature, genres,
                artist_id]


    for item in recently_played:
        recent_track_ids = [item['track']['id'] for item in recently_played]
        track_details.append(get_track_info(item['track']))

    # Gather track details from top tracks (short-term, mid-term, long-term)
    for track in top_tracks_short_term:
        track_details.append(get_track_info(track))

    for track in top_tracks_medium_term:
        track_details.append(get_track_info(track))

    for track in top_tracks_long_term:
        track_details.append(get_track_info(track))

    # Create a DataFrame
    columns = ['owner_id', 'track_id', 'has_listened', 'owner_name', 'track_name', 'duration_ms', 'danceability', 'energy',
            'key', 'loudness', 'mode', 'speechiness', 'acousticness', 'instrumentalness', 'liveness', 'valence', 'tempo',
            'time_signature', 'genres', 'artist_id']
    user_df = pd.DataFrame(track_details, columns=columns)
    user_df['owner_name'] = user_df['owner_name'].astype(str)
    user_df['track_name'] = user_df['track_name'].astype(str)
    user_df['genres'] = user_df['genres'].astype(str)

    user_df['genres'] = user_df['genres'].str.replace(r'\[|\]', '', regex=True).str.split(',')
    genres_df = user_df['genres'].apply(lambda x: pd.Series(x)).fillna('')
    user_df_one_hot = pd.get_dummies(genres_df.stack(), prefix='', prefix_sep='').groupby(level=0).sum()
    user_df_combined = user_df.drop(columns=['genres']).join(user_df_one_hot)
    exclude_columns = ['owner_id', 'track_id', 'has_listened', 'owner_name', 'track_name', 'duration_ms',
                    'danceability', 'energy', 'key', 'loudness', 'mode', 'speechiness',
                    'acousticness', 'instrumentalness', 'liveness', 'valence', 'tempo',
                    'time_signature', 'artist_id']
    columns_to_convert = user_df_combined.columns.difference(exclude_columns)
    user_df_combined[columns_to_convert] = user_df_combined[columns_to_convert].astype(int)
    user_df = user_df_combined.drop([''],axis=1)
    user_df = user_df.dropna()
    user_df = user_df.drop_duplicates()
    original_columns = set(df.columns)
    user_columns = set(user_df.columns)
    columns_to_drop = user_columns - original_columns
    columns_to_add = original_columns - user_columns
    user_df = user_df.drop(columns=columns_to_drop)
    for col in columns_to_add:
        user_df[col] = 0
    user_df = user_df[df.columns]

    le_owner = joblib.load('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\le_owner.pkl')
    le_track = joblib.load('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\le_track.pkl')


    # Function to handle new labels
    def update_label_encoder(le, new_labels):
        current_classes = set(le.classes_)
        new_classes = set(new_labels)
        classes_to_add = new_classes - current_classes
        if classes_to_add:
            le.classes_ = np.concatenate([le.classes_, list(classes_to_add)])
        return le


    # CF Part
    le_owner = update_label_encoder(le_owner, user_df['owner_id'])
    le_track = update_label_encoder(le_track, user_df['track_id'])
    user_df['owner_id_encoded'] = le_owner.transform(user_df['owner_id'])
    user_df['track_id_encoded'] = le_track.transform(user_df['track_id'])
    user_df = user_df.drop(user_df[user_df.track_id_encoded >= 8000].index, axis = 0)
    # Text Part
    user_track_name = tf.convert_to_tensor(user_df["track_name"], dtype=tf.string)
    # CBF Part
    user_cbf = user_df.drop(
        ['owner_id', 'track_id', 'has_listened', 'owner_name', 'track_name', 'owner_id_encoded', 'track_id_encoded'],
        axis=1)
    numeric_cols = ['duration_ms', 'danceability', 'energy', 'key', 'loudness', 'mode', 'speechiness', 'acousticness',
                    'instrumentalness', 'liveness', 'valence', 'tempo', 'time_signature']
    non_numeric_cols = [col for col in user_cbf.columns if col not in numeric_cols]
    user_cbf_pca = pca.transform(user_cbf[non_numeric_cols])
    cbf_user_pca_df = pd.DataFrame(data=user_cbf_pca, columns=[f'PCA_Component_{i + 1}' for i in range(50)])
    cbf_user_final = pd.concat([pd.DataFrame(scaler.transform(user_cbf[numeric_cols]), columns=numeric_cols),
                                cbf_user_pca_df], axis=1)


    early_stopping = EarlyStopping(monitor='val_loss', patience=4, verbose=1)
    batch_size = 8
    history = saved_model.fit([user_df['owner_id_encoded'], user_df['track_id_encoded'], user_track_name, cbf_user_final],
                            user_df['has_listened'],
                            epochs=25,
                            batch_size=batch_size,
                            validation_split=0.2,
                            callbacks=[early_stopping])

    user_encoded = le_owner.transform([user_id])[0]
    prediction_df = df.copy()
    prediction_df = prediction_df[
        ~((prediction_df['owner_id_encoded'] == user_encoded) & (prediction_df['has_listened'] == 1))]
    prediction_df['owner_id_encoded'] = user_encoded
    prediction_df = prediction_df.drop(prediction_df[prediction_df.track_id_encoded >= 8000].index, axis = 0)
    prediction_df = prediction_df.drop(prediction_df[prediction_df.owner_id_encoded >= 56].index, axis=0)
    prediction_df = prediction_df.drop_duplicates()
    numeric_cols = ['duration_ms', 'danceability', 'energy', 'key', 'loudness', 'mode', 'speechiness', 'acousticness',
                    'instrumentalness', 'liveness', 'valence', 'tempo', 'time_signature']
    cbf_prediction = prediction_df.drop(
        ['track_id', 'has_listened', 'owner_name', 'owner_id', 'track_name', 'owner_id_encoded', 'track_id_encoded'],
        axis=1)
    non_numeric_cols = [col for col in cbf_prediction.columns if col not in numeric_cols]
    cbf_prediction_pca = pca.transform(cbf_prediction[non_numeric_cols])
    cbf_prediction_pca_df = pd.DataFrame(data=cbf_prediction_pca, columns=[f'PCA_Component_{i + 1}' for i in range(50)])
    cbf_prediction_final = pd.concat([pd.DataFrame(scaler.transform(cbf_prediction[numeric_cols]), columns=numeric_cols),
                                    cbf_prediction_pca_df], axis=1)

    prediction_track_name = tf.convert_to_tensor(prediction_df['track_name'], dtype=tf.string)
    predictions = saved_model.predict(
        [prediction_df['owner_id_encoded'], prediction_df['track_id_encoded'], prediction_track_name, cbf_prediction_final])
    np.unique(predictions)
    prediction_df["pred"] = predictions
    sorted_df = prediction_df.drop(['owner_id', 'owner_name'], axis = 1).drop_duplicates().sort_values(by='pred', ascending=False)
    top_twenty_track_id_list = []

    # Iterate over sorted_df to fill the top_twenty_track_names_list
    for index, row in sorted_df.drop_duplicates().iterrows():
        if len(top_twenty_track_id_list) < 20:
            if row['track_id'] in df['track_id'].values:
                owner_names = df[df['track_name'] == row['track_name']]['owner_name']
                if not owner_names.empty and (owner_names != user_name).all():
                    if row['track_id'] not in user_df.track_id.values:
                        top_twenty_track_id_list.append(row['track_id'])

    top_twenty_track_names = sorted_df[sorted_df['track_id'].isin(top_twenty_track_id_list)]['track_name']
    top_twenty_track_names_list = top_twenty_track_names.tolist()
    top_twenty_track_names_list= np.unique(top_twenty_track_names_list)
    playlist_name = f"for {user_name}'s taste"
    playlist_description = 'new songs'
    playlist = sp.user_playlist_create(user=user_id, name=playlist_name, public=True, description=playlist_description)

    # Add tracks to the playlist
    sp.user_playlist_add_tracks(user=user_id, playlist_id=playlist['id'], tracks=top_twenty_track_id_list)
    return playlist['id']
