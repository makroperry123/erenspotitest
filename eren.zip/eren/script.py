import os
import time
import spotipy
from spotipy.oauth2 import SpotifyOAuth
import pandas as pd
import numpy as np
import joblib
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.callbacks import EarlyStopping
import random
import pickle
from tensorflow.keras.layers import TextVectorization

saved_model = load_model("C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\best_model.keras")
df = pd.read_csv('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\EMT_df_son.csv', index_col= [0])
scaler = joblib.load('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\scaler.pkl')
pca = joblib.load('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\pca.pkl')
with open('C:\\Users\\alpar.gul\\Desktop\\eren spoti\\eren\\text_vectorizer.pkl', 'rb') as f:
    text_vectorizer_data = pickle.load(f)
    text_vectorizer = TextVectorization.from_config(text_vectorizer_data['config'])
    text_vectorizer.set_weights(text_vectorizer_data['weights'])


# Set environment variables for Spotify API credentials
os.environ['SPOTIPY_CLIENT_ID'] = '4b74f041cd3f4008b87103430e8734ac'
os.environ['SPOTIPY_CLIENT_SECRET'] = 'd00aa43fa3644f30ae7e282826b07526'
os.environ['SPOTIPY_REDIRECT_URI'] = 'http://localhost:4444/callback/'

client_id = os.environ['SPOTIPY_CLIENT_ID']
client_secret = os.environ['SPOTIPY_CLIENT_SECRET']
redirect_uri = os.environ['SPOTIPY_REDIRECT_URI']
scope = 'user-read-recently-played user-top-read playlist-read-private playlist-modify-public user-library-read'

# Authenticate with Spotify
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(client_id=client_id,
                                               client_secret=client_secret,
                                               redirect_uri=redirect_uri,
                                               scope=scope,
                                               open_browser=True,
                                               cache_path=".cache_newest_902"))

# Fetch user's profile information
user_profile = sp.current_user()
user_id = user_profile['id']
user_name = user_profile['display_name']
recently_played = sp.current_user_recently_played(limit=50)['items']

# Fetch top listening tracks for different time ranges
top_tracks_short_term = sp.current_user_top_tracks(limit=50, time_range='short_term')['items']
top_tracks_medium_term = sp.current_user_top_tracks(limit=50, time_range='medium_term')['items']
top_tracks_long_term = sp.current_user_top_tracks(limit=50, time_range='long_term')['items']
