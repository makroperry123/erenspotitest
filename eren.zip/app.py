from flask import Flask, redirect, request, session, url_for
import os
import uuid
from flask_session import Session
from spotipy.oauth2 import SpotifyOAuth
import spotipy
from eren.recommendation import run_ml_model

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Spotify API credentials
client_id = 'b66c3f4ba1444dc49c4ae65a37c1f3a9'
client_secret = 'db64c9f065264003bf36dff5857bbb7a'
redirect_uri = 'http://192.168.0.19:5000/'  # Ensure this matches your Spotify Developer Dashboard

# Set environment variables
os.environ['SPOTIPY_CLIENT_ID'] = client_id
os.environ['SPOTIPY_CLIENT_SECRET'] = client_secret
os.environ['SPOTIPY_REDIRECT_URI'] = redirect_uri

SCOPE = 'user-read-recently-played user-top-read playlist-read-private playlist-modify-public user-library-read'
TOKEN_INFO = 'token_info'

app.config['SECRET_KEY'] = os.urandom(64)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = './.flask_session/'

Session(app)

caches_folder = './.spotify_caches/'
if not os.path.exists(caches_folder):
    os.makedirs(caches_folder)


def session_cache_path():
    return caches_folder + session.get('uuid')


# Custom SpotifyOAuth class to override the default behavior
class CustomSpotifyOAuth(SpotifyOAuth):
    def get_redirect_uri(self):
        return redirect_uri


@app.route('/')
def index():
    if not session.get('uuid'):
        # Step 1. Visitor is unknown, give random ID
        session['uuid'] = str(uuid.uuid4())

    auth_manager = CustomSpotifyOAuth(client_id=client_id,
                                      client_secret=client_secret,
                                      redirect_uri=redirect_uri,
                                      scope=SCOPE,
                                      cache_path=session_cache_path(),
                                      show_dialog=True)

    if request.args.get("code"):
        # Step 3. Being redirected from Spotify auth page
        auth_manager.get_access_token(request.args.get("code"))
        return redirect('/')

    if not auth_manager.get_cached_token():
        # Step 2. Display sign-in link when no token
        auth_url = auth_manager.get_authorize_url()
        return f'<h2><a href="{auth_url}">Sign in</a></h2>'

    # Step 4. Signed in, display data
    spotify = spotipy.Spotify(auth_manager=auth_manager)
    return f'<h2>Hi {spotify.me()["display_name"]}, ' \
           f'<small><a href="/sign_out">[sign out]<a/></small></h2>' \
           f'<a href="/Model">Start The Model</a> | ' \



@app.route('/Model')
def model():
    auth_manager = CustomSpotifyOAuth(client_id=client_id,
                                      client_secret=client_secret,
                                      redirect_uri=redirect_uri,
                                      scope=SCOPE,
                                      cache_path=session_cache_path())

    if not auth_manager.get_cached_token():
        return redirect('/')

    spotify = spotipy.Spotify(auth_manager=auth_manager)
    playlistid = run_ml_model(spotify)

    return  f'<h3> <a href="https://open.spotify.com/playlist/{playlistid}"> playlist link</h3>'


@app.route('/sign_out')
def sign_out():
    try:
        os.remove(session_cache_path())
        session.clear()
    except OSError as e:
        print("Error: %s - %s." % (e.filename, e.strerror))
    return f'<h2><a href="{url_for("/melih.html")}">return to start</a></h2>'


def cleanup():
    cache_file = '.cache'
    if os.path.exists(cache_file):
        os.remove(cache_file)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)